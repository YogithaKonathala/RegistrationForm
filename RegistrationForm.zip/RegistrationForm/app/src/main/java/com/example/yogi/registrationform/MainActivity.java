package com.example.yogi.registrationform;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;

public class MainActivity extends AppCompatActivity {
    EditText e1, e2, e3, e4;
    Button b;
    Spinner s1, s2;
    RadioGroup rg;
    CheckBox ch1, ch2, ch3, ch4;
    Bundle extras = new Bundle();
    RadioButton radioButton1, radioButton2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        e1 = findViewById(R.id.edit1);
        e2 = findViewById(R.id.edit2);
        e3 = findViewById(R.id.edit3);
        e4 = findViewById(R.id.edit4);
        s1 = findViewById(R.id.spinner1);
        s2 = findViewById(R.id.spinner2);
        rg = findViewById(R.id.rg1);
        ch1 = findViewById(R.id.check1);
        ch2 = findViewById(R.id.check2);
        ch3 = findViewById(R.id.check3);
        ch4 = findViewById(R.id.check4);
    }

    public void onSubmit(View view) {
        Intent i = new Intent(this, Main2Activity.class);

        String name = e1.getText().toString();
        extras.putString("NAME", name);
        String coll = e2.getText().toString();
        extras.putString("College", coll);
        String phno = e3.getText().toString();
        extras.putString("Phone Number", phno);
        String email = e4.getText().toString();
        extras.putString("EmailId", email);
        String branch = s1.getSelectedItem().toString();
        extras.putString("Branch", branch);
        String year = s2.getSelectedItem().toString();
        extras.putString("year", year);
        // String gender=rg.selected
        int selectedRadioButtonID = rg.getCheckedRadioButtonId();
        if (selectedRadioButtonID != -1) {

            RadioButton selectedRadioButton = (RadioButton) findViewById(selectedRadioButtonID);
            String selectedRadioButtonText = selectedRadioButton.getText().toString();

            extras.putString("Gender", selectedRadioButtonText);
        }

        i.putExtras(extras);
        startActivity(i);
    }

    public void onCheckBoxClicked(View view) {
        boolean checked = ((CheckBox) view).isChecked();
        switch (view.getId()) {
            case R.id.check1:
                if (ch1.isChecked()) {
                    String text1 = ch1.getText().toString();
                    extras.putString("Interest1", text1);
                } else
                    break;
            case R.id.check2:
                if (ch2.isChecked()) {
                    String text2 = ch2.getText().toString();
                    extras.putString("Interest2", text2);
                } else
                    break;
            case R.id.check3:
                if (ch3.isChecked()) {
                    String text3 = ch3.getText().toString();
                    extras.putString("Interest3", text3);
                } else
                    break;
            case R.id.check4:
                if (ch4.isChecked()) {
                    String text4 = ch4.getText().toString();
                    extras.putString("Interest4", text4);
                } else
                    break;

        }
    }
}



