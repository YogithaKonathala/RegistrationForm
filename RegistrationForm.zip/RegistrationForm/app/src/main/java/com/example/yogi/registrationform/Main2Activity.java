package com.example.yogi.registrationform;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class Main2Activity extends AppCompatActivity {
    TextView tv;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        tv=findViewById(R.id.tv1);
        Bundle bundle = getIntent().getExtras();
        String valueReceived1 = bundle .getString("NAME");
        String valueReceived2 = bundle .getString("College");
        String valueReceived3 = bundle .getString("Phone Number");
        String valueReceived4 = bundle .getString("EmailId");
        String valueReceived5 = bundle .getString("Branch");
        String valueReceived6 = bundle .getString("year");
        String valueReceived7 = bundle.getString("Gender");
        String valueReceived8 = bundle.getString("Interest1");
        String valueReceived9 = bundle.getString("Interest2");
        String valueReceived10 = bundle.getString("Interest3");
        String valueReceived11 = bundle.getString("Interest4");

        tv.setText(valueReceived1+"\n");
        tv.append(valueReceived2+"\n");
        tv.append(valueReceived3+"\n");
        tv.append(valueReceived4+"\n");
        tv.append(valueReceived5+"\n");
        tv.append(valueReceived6+"\n");
        tv.append(valueReceived7+"\n");
        if(valueReceived8!=null) {
            tv.append(valueReceived8 + "\n");
        }
        if(valueReceived9!=null) {
            tv.append(valueReceived9 + "\n");
        }
        if(valueReceived10!=null) {
            tv.append(valueReceived10 + "\n");
        }
        if(valueReceived11!=null) {
            tv.append(valueReceived11 + "\n");
        }





    }
}
